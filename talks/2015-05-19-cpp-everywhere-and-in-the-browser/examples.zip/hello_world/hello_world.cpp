#include <iostream>

int main(int argc, char** argv) {
  std::cout << "Hello sauter[devs] ! " << std::endl;
  return 0;
}

- Make the presentation a workshop about building an
    - Alarm Display Components which works the same on all platforms
    - With configurable list of alarms from an XML file




    /!\ Bananas are frozen, please stop processing...  
    ---     + 8 more


Write the code in front of us, show them it works now. And as you are tired you don't want to rewrite it for each platform, so simply show how it works to recompile for each platform.

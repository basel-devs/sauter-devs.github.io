cmake .. -DCMAKE_TOOLCHAIN_FILE=/opt/libs/emscripten-sysroot/toolchain-file.cmake
